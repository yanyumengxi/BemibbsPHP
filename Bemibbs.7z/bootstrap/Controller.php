<?php

namespace bemibbs;

use bemibbs\view\View;

/**
 * @author Lingqi <3615331065@qq.com>
 * @time 2022-05-16 16:17
 */
class Controller
{
    public string $layout = "index";
    public View $view;
    public function __construct()
    {
        $this->view = Application::$app->view;
    }

    public function setLayout($layout)
    {
        $this->layout = $layout;
    }

    public function render($view)
    {
//        return Application::$app->router->renderView($view, $param);
        Application::$app->view->show($view);
    }
}