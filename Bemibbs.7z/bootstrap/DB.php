<?php

namespace bemibbs;

use PDO;

/**
 * @author Linqgi <3615331065@qq.com>
 * @time 2022-05-16 19:15
 */
class DB
{
    public PDO $PDO;
    public function __construct()
    {

    }
}