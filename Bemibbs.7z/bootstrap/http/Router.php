<?php

namespace bemibbs\http;

use bemibbs\Application;
use bemibbs\Exception;

class Router
{
    /**
     * @var Request
     */
    public Request $request;
    public Response $response;
    protected array $routes = [];

    /**
     * Route 构造方法
     * @param Request $request
     * @param Response $response
     */
    public function __construct(Request $request, Response $response)
    {
        $this->request = $request;
        $this->response = $response;
    }

    public function get($path, $callback)
    {
        $this->routes['get'][$path] = $callback;
    }

    public function post($path, $callback)
    {
        $this->routes['post'][$path] = $callback;
    }
    public function put($path, $callback)
    {
        $this->routes['put'][$path] = $callback;
    }
    public function all($path, $callback)
    {
        $this->routes['*'][$path] = $callback;
    }
    public function method($method, $path, $callback){
        $this->routes[$method][$path] = $callback;
    }

    public function resolve()
    {
        $path = $this->request->getPath();
        $method = $this->request->method();
        echo $method;
        $callback = $this->routes[$method][$path] ?? false;
        if ($callback === false) {
            $this->response->setStatusCode(404);
            Application::$app->view->show("404");
            return "";
        }
        if (is_string($callback)) {
            Application::$app->view->show($callback);
            return "";
        }
        if (is_array($callback)) {
            $path = Application::$ROOT_DIR . '/' . $callback[0] . ".php";
            if (file_exists($path)) {
                Application::$app->controller = new $callback[0]();
            } else {
                Exception::throw("控制器不存在！！！");
            }
            $callback[0] = Application::$app->controller;
        }
        return call_user_func($callback, $this->request);
    }

//    public function renderView($view, $params = [])
//    {
//        $layoutContent = Application::$app->view->render($this->layoutContent());
//        $viewContent = $this->renderOnlyView($view, $params);
//        return str_replace("{{IndexLayout}}", $viewContent, $layoutContent);
//    }
//
//    public function renderContent($viewContent)
//    {
//        $layoutContent = $this->layoutContent();
//        return str_replace("{{IndexLayout}}", $viewContent, $layoutContent);
//    }
//
//    protected function layoutContent()
//    {
//        $layout = Application::$app->controller->layout;
//        ob_start();
//        include_once Application::$ROOT_DIR . "/app/views/layouts/$layout.php";
//        return ob_get_clean();
//    }
//
//    public function renderOnlyView($view, $params)
//    {
//        foreach ($params as $key => $value) {
//            $$key = $value;
//        }
//        ob_start();
//        include_once Application::$ROOT_DIR . "/app/views/$view.php";
//        return ob_get_clean();
//    }
}