<?php

require_once __DIR__.'/vendor/autoload.php';

use app\controllers\SiteController;
use bemibbs\Application;

$app = new Application(__DIR__);

$app->router->get('/', [SiteController::class, 'index']);

//$app->router->get('/', function () {
//    Application::$app->view->render("sss");
//});
//$app->router->post('/', [SiteController::class, 'handleHome']);
$app->router->get('/home', [SiteController::class, 'home']);
$app->router->post('/home', [SiteController::class, 'home']);
$app->router->put('/home', [SiteController::class, 'home']);
$app->router->method('view', '/home', [SiteController::class, 'home']);
//$app->router->all('/home', [SiteController::class, 'home']);
//$app->router->get('/login', [AuthorController::class, 'login']);
//$app->router->post('/login', [AuthorController::class, 'login']);
//$app->router->get('/register', [AuthorController::class, 'register']);
//$app->router->post('/register', [AuthorController::class, 'register']);
$app->run();