<?php

namespace app\controllers;

use bemibbs\Controller;
use bemibbs\http\Request;

/**
 * @author Lingqi <3615331065@qq.com>
 * @time 2022-05-16 15:51
 */
class SiteController extends Controller
{
    public function home()
    {
        $ars = array(
            'a' => 'A',
            'b' => 'B',
            'c' => 'C'
        );
        $this->view->assign('arr', $ars);
        $this->render('index');
    }

    public function index()
    {
        $ars = array(
            'a' => 'A',
            'b' => 'B',
            'c' => 'C'
        );
        $this->view->assign("Title", "Bemi Framework");
        $this->view->assign("PASSWORD", "This is a Password");
        $this->view->assign('arr', $ars);
        $this->view->assign('a', '1');
        $this->view->show('index');
    }

    public function handleHome(Request $request)
    {
        $body = $request->getBody();
        echo "<pre>";
        var_dump($body);
        echo "</pre>";
        exit;
        return "Handler Submit Form";
    }
}