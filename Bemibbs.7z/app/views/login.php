<?php
?>
<h1>Login</h1>
<form action="" method="post">
    <label for="name">用户名:</label>
    <input type="text" id="name" name="name" value="NamesHHH">
    <br>
    <label for="nickname">昵&nbsp;&nbsp;&nbsp;称:</label>
    <input type="text" id="nickname" name="nickname" value="NamesHHH">
    <br>
    <button type="submit">Submit！</button>
</form>