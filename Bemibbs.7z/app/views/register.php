<?php
?>
<h1>Register</h1>
<form action="" method="post">
    <label for="username">用户名:</label>
    <input
        type="text"
        id="username"
        name="username"
        value="<?php echo $model->username;?>"
        class="<?php echo $model->hasError('firstname') ? ' is-invalid' : ''?>">
    <div>
        <?php echo $model->getError('username') ?>
    </div>
    <br>
    <label for="nickname">昵&nbsp;&nbsp;&nbsp;称:</label>
    <input type="text" id="nickname" name="nickname" value="<?php echo $model->nickname;?>">
    <br>
    <button type="submit">Submit！</button>
</form>