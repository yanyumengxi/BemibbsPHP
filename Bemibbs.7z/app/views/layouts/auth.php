<p>Auth</p>
<div>
    {{IndexLayout}}
</div>