<?php
include_once __DIR__."./tools/Message.addon.php";